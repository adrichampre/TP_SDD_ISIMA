/* -------------------------------------------------------------------- */
/* 						Fichier d'entête tp2    						*/
/*                                                             			*/
/* -------------------------------------------------------------------- */


#include "pile.h"
#include "file.h"



int InverseEntierPile(pile_t * pile, file_t * file);